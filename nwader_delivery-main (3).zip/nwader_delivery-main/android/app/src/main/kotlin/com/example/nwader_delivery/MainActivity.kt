package com.example.nwader_delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
